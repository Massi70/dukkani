



         <?php /*?> <!--<div class="grid_7" style="width:50%">

          <a href="<?php echo base_url();?>admin/users" class="dashboard-module"><img src="<?php echo base_url();?>images/admin/users.jpeg"  width="64" height="64"  /> <span>Users Management</span> </a>

          <a href="<?php echo base_url();?>admin/video" class="dashboard-module"> <img src="<?php echo base_url();?>images/admin/video.png" width='70'  /> <span>Video Management</span> </a>

          

          <a href="<?php echo base_url();?>admin/content" class="dashboard-module"> <img src="<?php echo base_url();?>images/admin/content.png" width='70'  /> <span>Content Management</span> </a>

          

          <a href="<?php echo base_url();?>admin/add" class="dashboard-module"> <img src="<?php echo base_url();?>images/admin/advertising.png" width='70'  /> <span>Advertisement Management</span> </a>

          <div style="clear: both"></div>

  </div>--><?php */?>

  <div style="margin-top:-2%;" class="grid_5">           

<div style="margin-right:-10px;" class="module">

  <h2><span>Application Statistics :</span></h2>

  <div class="module-body">

    <p> <strong>Total Users (Application Joined): </strong><?php echo $totalAppUsers;?>    

    <br>

    </p>

    

   </div>

</div>



 <div style="clear: both"></div>

  </div>





